namespace api.Models
{
    public class EnrollmentFailureResult
    {
        public string? CourseCode { get; set; }
        public string? ErrorMessage { get; set; }
    }
}
