namespace api.Models.DTOs
{
    public class ValidationErrorMessage
    {
        public string ErrorMessage { get; set; } = null!;
    }
}
