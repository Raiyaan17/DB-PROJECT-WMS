namespace api.Models.DTOs
{
    public class PrerequisiteDto
    {
        public string? CourseCode { get; set; }
        public string? CourseTitle { get; set; }
    }
}
